const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'avatar',
    description: 'Shows a user\'s avatar along with a fun comment.',
    options: [
        {
            name: 'user',
            description: 'Select a user to view their avatar',
            type: ApplicationCommandOptionType.User,
            required: false // Make this optional to allow defaulting to command user
        }
    ],
    async execute({ inter }) {
        try {
            // Get the selected user or default to the command user
            const user = inter.options.getUser('user') || inter.user;
            
            // Get the avatar URL (ensure it's always available)
            const avatarURL = user.displayAvatarURL({ dynamic: true, size: 1024 });

            // Array of funny messages
            const funnyMessages = [
                "Wow, what a face! 🚀",
                "Looking sharp! ✨",
                "That's a face only a mother could love! 😂",
                "Say cheese! 🧀",
                "Your avatar just broke the internet! 📸",
                "Is this a model or a user? 🤔",
                "Smile for the bot! 🤖",
                "Is that you or a celebrity? 🌟",
                "Too cool for school! 😎",
                "You're a rockstar! 🎸",
                "Did you just come from a photoshoot? 📸",
                "Mirror, mirror on the wall, who has the best avatar of all? 🤔",
                "That's the face of someone who just won the internet. 🏆",
                "Your avatar is cooler than my algorithms! ❄️",
                "Channeling your inner superstar, I see. 💃",
                "That smile can light up a whole server! 💡",
                "Too cute to compute! 🥰",
                "Ready for your close-up! 🎥",
                "If avatars could talk, yours would have a lot to say! 🗣️",
                "Is that a masterpiece or your avatar? 🎨",
                "Your avatar just joined the hall of fame! 🏅",
                "Photogenic much? You nailed it! 📷",
                "Behold, the royalty of avatars! 👑",
                "That avatar's got style for days! 👗",
                "Stop stealing hearts with that avatar! 💔",
                "Looking flawless as ever! ✨",
                "Not even a filter can compete with that look! 💯",
                "Your avatar just made my day! 😄",
                "Click! Captured perfection! 📸",
                "Smile, you're on virtual camera! 🎥"
            ];

            // Select a random funny message
            const randomMessage = funnyMessages[Math.floor(Math.random() * funnyMessages.length)];

            // Create the embed with the translated title and description
            const avatarEmbed = new EmbedBuilder()
                .setColor('#2f3136')
                .setTitle(await Translate('User Avatar'))
                .setDescription(await Translate(`Here is the avatar of <@${user.id}> - ${randomMessage}`))
                .setImage(avatarURL)
                .setFooter({ text: inter.guild.name, iconURL: inter.guild.iconURL({ dynamic: true }) })
                .setTimestamp();

            // Send the embed
            await inter.editReply({ embeds: [avatarEmbed] });
        } catch (error) {
            console.error('Error in avatar command:', error);
            await inter.editReply(await Translate('❌ Something went wrong while fetching the avatar.'));
        }
    }
};