const { PermissionsBitField, ApplicationCommandOptionType } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'msgclear',
    description: 'Clear a specified number of messages from the channel.',
    permissions: PermissionsBitField.Flags.Administrator,
    options: [
        {
            name: 'amount',
            description: 'Number of messages to delete',
            type: ApplicationCommandOptionType.Integer,
            required: true,
        },
    ],

    async execute({ inter }) {
        // Ensure the command is only used by administrators
        if (!inter.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return inter.reply({ content: await Translate('❌ | Only administrators can use this command.'), ephemeral: true });
        }

        const amount = inter.options.getInteger('amount');

        if (!amount || isNaN(amount) || amount < 1 || amount > 100) {
            return inter.editReply(await Translate('❌ | Please specify a valid number between 1 and 100.'));
        }

        if (!inter.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            return inter.editReply(await Translate('❌ | I do not have permission to manage messages in this channel.'));
        }

        try {
            // Fetch messages
            const fetchedMessages = await inter.channel.messages.fetch({ limit: Math.min(amount, 100) });

            if (fetchedMessages.size === 0) {
                return inter.editReply(await Translate('❌ | No messages found to delete.'));
            }

            // Bulk delete messages
            const deletedMessages = await inter.channel.bulkDelete(fetchedMessages, true);

            if (deletedMessages.size === 0) {
                return inter.editReply(await Translate('❌ | Could not delete messages. Make sure they are not older than 14 days.'));
            }

            let replyMessage = `✅ | Successfully deleted **${deletedMessages.size}** message(s)!`;

            if (deletedMessages.size < fetchedMessages.size) {
                replyMessage += '\n⚠️ | Some messages could not be deleted because they are older than 14 days.';
            }

            inter.editReply(await Translate(replyMessage));

        } catch (error) {
            console.error('Error deleting messages:', error);
            inter.editReply(await Translate('❌ | There was an error trying to delete messages.'));
        }
    }
};