const { ApplicationCommandOptionType, PermissionsBitField, EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'giverole',
    description: 'Add or remove a role from a specified user.',
    permissions: PermissionsBitField.Flags.Administrator, // Require Administrator permission
    options: [
        {
            name: 'action',
            description: 'Specify whether to add or remove the role',
            type: ApplicationCommandOptionType.String,
            choices: [
                { name: 'Add', value: 'add' },
                { name: 'Remove', value: 'remove' }
            ],
            required: true
        },
        {
            name: 'user',
            description: 'The user to add/remove the role from',
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: 'role',
            description: 'The role to add/remove',
            type: ApplicationCommandOptionType.Role,
            required: true
        }
    ],

    async execute({ inter }) {
        try {
            // Ensure the command is only used by administrators
            if (!inter.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return inter.reply({ content: await Translate('❌ | Only administrators can use this command.'), ephemeral: true });
            }

            const action = inter.options.getString('action');
            const user = inter.options.getUser('user');
            const role = inter.options.getRole('role');

            // Ensure the bot has permission to manage roles
            if (!inter.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                return inter.editReply(await Translate('<❌> | I do not have permission to manage roles.'));
            }

            // Fetch the member to add/remove the role from
            const member = await inter.guild.members.fetch(user.id).catch(() => null);

            if (!member) {
                return inter.editReply(await Translate(`<❌> | Could not find ${member.displayName} in this server.`));
            }

            // Ensure the bot's highest role is higher than the role to assign
            if (role.position >= inter.guild.members.me.roles.highest.position) {
                return inter.editReply(await Translate('<❌> | I cannot modify this role because it is higher than my highest role.'));
            }

            if (action === 'add') {
                // Check if the user already has the role
                if (member.roles.cache.has(role.id)) {
                    return inter.editReply(await Translate(`<❌> | ${member.displayName} already has the ${role.name} role.`));
                }

                // Add the role to the member
                await member.roles.add(role);

                const embed = new EmbedBuilder()
                    .setColor('00ff00')
                    .setDescription(await Translate(`✅ | Successfully added the ${role.name} role to ${user.tag}.`));

                return inter.editReply({ embeds: [embed] });

            } else if (action === 'remove') {
                // Check if the user has the role
                if (!member.roles.cache.has(role.id)) {
                    return inter.editReply(await Translate(`<❌> | ${member.displayName} does not have the ${role.name} role.`));
                }

                // Remove the role from the member
                await member.roles.remove(role);

                const embed = new EmbedBuilder()
                    .setColor('RED')
                    .setDescription(await Translate(`✅ | Successfully removed the ${role.name} role from ${member.displayName}.`));

                return inter.editReply({ embeds: [embed] });

            } else {
                return inter.editReply(await Translate('<❌> | Invalid action specified.'));
            }

        } catch (error) {
            console.error('Error in /giverole command:', error);
            return inter.editReply(await Translate('<❌> | An error occurred while processing the giverole command.'));
        }
    }
};