const { ApplicationCommandOptionType, PermissionsBitField, EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'lockchannel',
    description: 'Lock or unlock a specified text channel.',
    permissions: PermissionsBitField.Flags.ManageChannels, // Require ManageChannels permission
    options: [
        {
            name: 'action',
            description: 'Specify whether to lock or unlock the channel',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                { name: 'Lock', value: 'lock' },
                { name: 'Unlock', value: 'unlock' }
            ]
        },
        {
            name: 'channel',
            description: 'The channel to lock or unlock',
            type: ApplicationCommandOptionType.Channel,
            required: true
        }
    ],

    async execute({ inter }) {
        try {
            // Ensure the command is only used by administrators
            if (!inter.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return inter.reply({ content: await Translate('<❌> | Only administrators can use this command.'), ephemeral: true });
            }

            const action = inter.options.getString('action');
            const channel = inter.options.getChannel('channel');

            // Ensure the channel is a text channel
            if (!channel.isTextBased()) {
                return inter.editReply({ content: await Translate('❌ | You need to select a text channel.') });
            }

            const everyoneRole = inter.guild.roles.everyone;

            if (action === 'lock') {
                await channel.permissionOverwrites.edit(everyoneRole, { SendMessages: false });

                const embed = new EmbedBuilder()
                    .setColor('ff0000')
                    .setDescription(await Translate(`🔒 | The ${channel.name} channel has been locked.`));

                await channel.send({ embeds: [embed] });
                return inter.editReply(await Translate(`✅ | Successfully locked the ${channel.name} channel.`));

            } else if (action === 'unlock') {
                await channel.permissionOverwrites.edit(everyoneRole, { SendMessages: true });

                const embed = new EmbedBuilder()
                    .setColor('00ff00')
                    .setDescription(await Translate(`🔓 | The ${channel.name} channel has been unlocked.`));

                await channel.send({ embeds: [embed] });
                return inter.editReply(await Translate(`✅ | Successfully unlocked the ${channel.name} channel.`));

            } else {
                return inter.editReply(await Translate('<❌> | Invalid action specified.'));
            }
        } catch (error) {
            console.error('Error in /lockchannel command:', error);
            return inter.editReply(await Translate('<❌> | An error occurred while processing the lockchannel command.'));
        }
    }
};