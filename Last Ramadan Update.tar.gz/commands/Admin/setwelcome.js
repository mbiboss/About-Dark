const { ApplicationCommandOptionType, EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { Translate } = require('../../process_tools');

function updateServerSettings(guildId, type, channelId) {
    const settingsPath = path.join(__dirname, '../../serverSettings.json');
    let settings = fs.existsSync(settingsPath) 
        ? JSON.parse(fs.readFileSync(settingsPath, 'utf-8')) 
        : {};

    settings[guildId] = settings[guildId] || {};
    settings[guildId][`${type}ChannelId`] = channelId;

    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2), 'utf-8');
}

module.exports = {
    name: 'setwelcome',
    description: "📢 Configure the welcome/leave channels.",
    permissions: PermissionsBitField.Flags.Administrator, // Require Administrator permission
    options: [
        {
            name: 'type',
            description: 'Choose Welcome or Leave channel',
            type: ApplicationCommandOptionType.String,
            choices: [
                { name: 'Welcome', value: 'welcome' },
                { name: 'Leave', value: 'leave' }
            ],
            required: true
        },
        {
            name: 'channel',
            description: 'Select the channel',
            type: ApplicationCommandOptionType.Channel,
            required: true
        }
    ],

    async execute({ inter }) {
        try {
            // Ensure the command is only used by administrators
            if (!inter.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return inter.reply({ content: await Translate('❌ | Only administrators can use this command.'), ephemeral: true });
            }

            const guildId = inter.guild.id;
            const type = inter.options.getString('type');
            const channel = inter.options.getChannel('channel');

            // Ensure it's a valid text channel
            if (!channel.isTextBased()) {
                return inter.editReply({ content: await Translate('❌ You need to select a text channel!') });
            }

            // Update the server settings
            updateServerSettings(guildId, type, channel.id);

            const successMessage = new EmbedBuilder()
                .setAuthor({ name: await Translate(`✅ ${type.charAt(0).toUpperCase() + type.slice(1)} channel set successfully!`) })
                .setDescription(await Translate(`Messages will be sent in ${channel.name}.`))
                .setColor('#2f3136');

            inter.editReply({ embeds: [successMessage] });

        } catch (error) {
            console.error('Setwelcome Error:', error);
            inter.editReply({ content: await Translate('❌ Configuration failed!'), ephemeral: true });
        }
    }
};