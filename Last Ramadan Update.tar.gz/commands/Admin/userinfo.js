const { ApplicationCommandOptionType, EmbedBuilder, PermissionsBitField, UserFlagsBitField } = require('discord.js');
const { Translate } = require('../../process_tools');
const imgids = require('../../imgurl');

module.exports = {
    name: 'userinfo',
    description: 'Get a detailed profile of any user.',
    permissions: PermissionsBitField.Flags.ViewChannel,
    options: [
        {
            name: 'user',
            description: 'Select a user to fetch details',
            type: ApplicationCommandOptionType.User,
            required: true
        }
    ],

    async execute({ inter }) {
        try {
            const user = inter.options.getUser('user');
            const member = await inter.guild.members.fetch(user.id).catch(() => null);

            if (!member) {
                return inter.editReply(await Translate(`<❌> | Could not find ${user.tag} in this server.`, inter.guild.id));
            }

            const userFetch = await user.fetch(true);
            const bannerUrl = userFetch.banner ? `https://cdn.discordapp.com/banners/${user.id}/${user.banner}.png?size=1024` : null;
            const activities = member.presence?.activities || [];
            let activityDetails = 'None';

            if (activities.length > 0) {
                const activity = activities[0];
                switch (activity.type) {
                    case 0: activityDetails = `🎮 Playing **${activity.name}**`; break;
                    case 1: activityDetails = `🎥 Streaming **${activity.name}**`; break;
                    case 2: activityDetails = `🎧 Listening to **${activity.details}**`; break;
                    case 3: activityDetails = `📺 Watching **${activity.name}**`; break;
                    case 5: activityDetails = `💼 Competing in **${activity.name}**`; break;
                }
            }

            const isBot = user.bot ? '🤖 **Bot Account**' : '👤 **Human Account**';
            const has2FA = member.user.mfaEnabled ? '✅ **Enabled**' : '❌ **Disabled**';
            const boosting = member.premiumSince ? `<t:${Math.floor(member.premiumSinceTimestamp / 1000)}:R>` : '❌ Not Boosting';
            const profileLink = `[Click Here](https://discord.com/users/${user.id})`;
            const highestRole = member.roles.highest.name !== '@everyone' ? member.roles.highest.name : 'None';
            const totalRoles = member.roles.cache.size - 1;
            let nitroStatus = '❌ No Nitro';
            if (userFetch.premiumType === 2) nitroStatus = '🚀 **Nitro Full**';
            if (userFetch.premiumType === 1) nitroStatus = '⚡ **Nitro Basic**';
            const hexColor = member.displayHexColor === '#000000' ? 'Default' : member.displayHexColor;
            const topPermissions = member.permissions.toArray().slice(0, 5).map(perm => `• ${perm.replace(/_/g, ' ')}`).join('\n') || 'None';
            const voiceChannel = member.voice.channel ? `🔊 **${member.voice.channel.name}**` : '❌ Not in VC';
            const userFlags = user.flags.toArray();
            const badges = userFlags.length ? userFlags.map(flag => `• ${flag.replace(/_/g, ' ')}`).join('\n') : 'None';

            const embed = new EmbedBuilder()
                .setColor(member.displayHexColor || '0000ff')
                .setTitle(`${member.displayName}'s Profile`)
                .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 1024 }))
                .setDescription(`\`\`\`
🔗 Profile: ${profileLink}
🌟 Badges: ${badges}
\`\`\``)
                .addFields(
                    { name: '🆔 User ID', value: `\`\`\`${user.id}\`\`\``, inline: true },
                    { name: '🛠️ Account Type', value: `\`\`\`${isBot}\`\`\``, inline: true },
                    { name: '💳 Nitro Status', value: `\`\`\`${nitroStatus}\`\`\``, inline: true },
                    { name: '🖋 About Me', value: `\`\`\`${userFetch.about || 'None'}\`\`\``, inline: false },
                    { name: '🛡️ 2FA Protection', value: `\`\`\`${has2FA}\`\`\``, inline: true },
                    { name: '🎨 Username Color', value: `\`\`\`${hexColor}\`\`\``, inline: true },
                    { name: '🎭 Highest Role', value: `\`\`\`${highestRole}\`\`\``, inline: true },
                    { name: '📌 Total Roles', value: `\`\`\`${totalRoles}\`\`\``, inline: true },
                    { name: '⚙️ Key Permissions', value: `\`\`\`${topPermissions}\`\`\``, inline: false },
                    { name: '🎮 Current Activity', value: `\`\`\`${activityDetails}\`\`\``, inline: false },
                    { name: '🚀 Boosting Server', value: boosting, inline: true },
                    { name: '📍 Voice Channel', value: `\`\`\`${voiceChannel}\`\`\``, inline: true },
                    { name: '📆 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
                    { name: '📆 Joined Discord', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true }
                )
                .setFooter({ text: `Requested by ${inter.member.user.tag}`, iconURL: inter.member.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            if (bannerUrl) {
                embed.setImage(bannerUrl);
            } else {
                embed.setImage(imgids.img3);
            }

            return inter.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Error in /userinfo command:', error);
            return inter.editReply({ content: await Translate('<❌> | An error occurred while fetching user information.', inter.guild.id) });
        }
    }
};