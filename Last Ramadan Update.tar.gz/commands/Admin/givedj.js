const { EmbedBuilder, PermissionsBitField, ApplicationCommandOptionType, InteractionType } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'givedj',
    description: 'Assign or remove the DJ role to/from a selected user.',
    permissions: PermissionsBitField.Flags.ManageRoles,
    options: [
        {
            name: 'action',
            description: 'Specify whether to add or remove the DJ role',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                { name: 'Add', value: 'add' },
                { name: 'Remove', value: 'remove' }
            ]
        },
        {
            name: 'user',
            description: 'The user to assign/remove the DJ role',
            type: ApplicationCommandOptionType.User,
            required: true,
        }
    ],

    async execute({ inter, client }) {
        try {
            // Ensure the command is only used by administrators
            if (!inter.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return inter.editReply(await Translate('<❌> | Only administrators can use this command.'));
            }

            // Ensure we only defer once
            if (!inter.deferred && !inter.replied) {
                await inter.deferReply({ ephemeral: true });
            }

            const action = inter.options.getString('action');
            const user = inter.options.getUser('user');
            const member = await inter.guild.members.fetch(user.id).catch(() => null);

            if (!member) {
                return inter.editReply(await Translate('<❌> | Could not find the specified user in this server.'));
            }

            let djRole = inter.guild.roles.cache.find(role => role.name === '◁━━━━◈DJ◈━━━━▷');

            if (!djRole) {
                if (action === 'add') {
                    if (!inter.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                        return inter.editReply(await Translate('<❌> | I do not have permission to create roles.'));
                    }

                    djRole = await inter.guild.roles.create({
                        name: '◁━━━━◈DJ◈━━━━▷',
                        color: '#FF0000',
                        reason: 'Needed for DJ commands',
                        permissions: [
                            PermissionsBitField.Flags.Connect,
                            PermissionsBitField.Flags.Speak,
                            PermissionsBitField.Flags.Stream,
                            PermissionsBitField.Flags.UseVAD,
                            PermissionsBitField.Flags.PrioritySpeaker,
                            PermissionsBitField.Flags.MoveMembers,
                            PermissionsBitField.Flags.DeafenMembers,
                            PermissionsBitField.Flags.MuteMembers,
                            PermissionsBitField.Flags.ViewChannel,
                            PermissionsBitField.Flags.SendMessages,
                            PermissionsBitField.Flags.EmbedLinks,
                            PermissionsBitField.Flags.AttachFiles,
                            PermissionsBitField.Flags.AddReactions,
                            PermissionsBitField.Flags.ReadMessageHistory,
                            PermissionsBitField.Flags.UseExternalEmojis,
                            PermissionsBitField.Flags.UseApplicationCommands,
                        ],
                        position: inter.guild.members.me.roles.highest.position - 1
                    }).catch(() => null);

                    if (!djRole) {
                        return inter.editReply(await Translate('<❌> | Failed to create the DJ role.'));
                    }
                } else {
                    return inter.editReply(await Translate('<❌> | DJ role does not exist.'));
                }
            }

            if (!inter.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                return inter.editReply(await Translate('<❌> | I do not have permission to assign/remove roles.'));
            }

            if (djRole.position >= inter.guild.members.me.roles.highest.position) {
                return inter.editReply(await Translate('<❌> | I cannot modify the DJ role because it is higher than my highest role.'));
            }

            if (action === 'add') {
                if (member.roles.cache.has(djRole.id)) {
                    return inter.editReply(await Translate(`<❌> | ${member.displayName} already has the DJ role!`));
                }

                await member.roles.add(djRole);
                return inter.editReply(await Translate(`✅ Successfully gave ${member.displayName} the DJ role! 🎶`));
            } else if (action === 'remove') {
                if (!member.roles.cache.has(djRole.id)) {
                    return inter.editReply(await Translate(`<❌> | ${member.displayName} does not have the DJ role!`));
                }

                await member.roles.remove(djRole);
                return inter.editReply(await Translate(`✅ Successfully removed the DJ role from ${member.displayName}! 🎶`));
            }

        } catch (error) {
            console.error('Error in /givedj command:', error);

            // Ensure we only reply once
            if (!inter.replied && !inter.deferred) {
                await inter.deferReply({ ephemeral: true }).catch(() => {});
            }

            return inter.editReply(await Translate('<❌> | An error occurred while processing the DJ role.'));
        }
    },

    async autocomplete(inter, client) {
        const focusedOption = inter.options.getFocused(true);
        const action = inter.options.getString('action');

        if (focusedOption.name === 'user') {
            let members;
            const djRole = inter.guild.roles.cache.find(role => role.name === '◁━━━━◈DJ◈━━━━▷');

            if (action === 'remove') {
                if (!djRole) {
                    return inter.respond([]);
                }
                members = inter.guild.members.cache.filter(member => !member.user.bot && member.roles.cache.has(djRole.id));
            } else {
                members = inter.guild.members.cache.filter(member => !member.user.bot && !member.roles.cache.has(djRole?.id));
            }

            const choices = members.map(member => ({
                name: member.displayName,
                value: member.id
            }));

            const filtered = choices
                .filter(choice => choice.name.toLowerCase().includes(focusedOption.value.toLowerCase()))
                .slice(0, 25);

            await inter.respond(filtered);
        }
    }
};