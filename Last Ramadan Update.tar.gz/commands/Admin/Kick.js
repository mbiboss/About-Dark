const { ApplicationCommandOptionType, PermissionsBitField, EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'kick',
    description: 'Kick a member from the server.',
    permissions: PermissionsBitField.Flags.KickMembers, // Require KickMembers permission
    options: [
        {
            name: 'user',
            description: 'The user to kick',
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: 'reason',
            description: 'Reason for kicking the user (optional)',
            type: ApplicationCommandOptionType.String,
            required: false
        }
    ],

    async execute({ inter }) {
        try {
            const user = inter.options.getUser('user');
            const reason = inter.options.getString('reason') || 'No reason provided';

            // Ensure the bot has permission to kick members
            if (!inter.guild.members.me.permissions.has(PermissionsBitField.Flags.KickMembers)) {
                return inter.editReply(await Translate('<❌> | I do not have permission to kick members.'));
            }

            // Fetch the member to kick
            const member = await inter.guild.members.fetch(user.id).catch(() => null);

            if (!member) {
                return inter.editReply(await Translate(`<❌> | Could not find ${member.displayName} in this server.`));
            }

            // Self-kick check
            if (member.id === inter.member.id) {
                return inter.editReply(await Translate('<❌> | You cannot kick yourself.'));
            }

            // Owner kick check
            if (member.id === inter.guild.ownerId) {
                return inter.editReply(await Translate('<❌> | You cannot kick the server owner.'));
            }

            // Ensure the administrator's role is higher than the member's role
            if (member.roles.highest.position >= inter.member.roles.highest.position && inter.guild.ownerId !== inter.member.id) {
                return inter.editReply(await Translate('<❌> | You cannot kick this user because they have a higher or equal role.'));
            }

            // Check if the member is kickable by the bot
            if (!member.kickable) {
                return inter.editReply(await Translate('<❌> | I cannot kick this user. They might have higher roles than me.'));
            }

            // Kick the member
            await member.kick(reason);

            const embed = new EmbedBuilder()
                .setColor('ff0000')
                .setDescription(await Translate(`✅ | Successfully kicked ${member.displayName}! Reason: ${reason}`));

            // Send the kick message to the channel where the command was executed
            await inter.channel.send({ embeds: [embed] });

            // Optionally, send an ephemeral confirmation to the user who executed the command
            return inter.editReply(await Translate(`✅ | You have successfully kicked ${member.displayName}.`));
            
        } catch (error) {
            console.error('Error in /kick command:', error);
            return inter.editReply(await Translate('<❌> | An error occurred while processing the kick command.'));
        }
    }
};