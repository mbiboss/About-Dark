const { ApplicationCommandOptionType, PermissionsBitField } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'nick',
    description: 'Change or reset a user\'s nickname.',
    permissions: PermissionsBitField.Flags.ManageNicknames, // Require Manage Nicknames permission
    options: [
        {
            name: 'user',
            description: 'The user to change the nickname for.',
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: 'nickname',
            description: 'The new nickname (leave empty to reset).',
            type: ApplicationCommandOptionType.String,
            required: false
        }
    ],

    async execute({ inter }) {
        // Check if the user has the Administrator permission
        if (!inter.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return inter.reply({ content: await Translate('❌ | You do not have permission to use this command.', inter.guild.id), ephemeral: true });
        }

        // Defer the reply to avoid interaction timeouts
        if (!inter.deferred && !inter.replied) {
            await inter.deferReply({ ephemeral: true });
        }

        const member = inter.options.getMember('user');
        const newNickname = inter.options.getString('nickname');

        if (!member) {
            return inter.editReply({ content: await Translate('User not found.', inter.guild.id) });
        }

        try {
            let replyMessage;

            if (newNickname) {
                await member.setNickname(newNickname);
                replyMessage = `✅ | Nickname for ${member.displayName} has been changed to **${newNickname}**.`;
            } else {
                await member.setNickname(null);
                replyMessage = `✅ | Nickname for ${member.displayName} has been reset.`;
            }

            await inter.editReply({ content: await Translate(replyMessage, inter.guild.id) });

        } catch (error) {
            console.error(error);

            // Ensure interaction hasn't already been replied to
            if (inter.deferred) {
                return inter.followUp({ content: await Translate('❌ | An error occurred while changing the nickname.', inter.guild.id), ephemeral: true });
            }

            await inter.reply({ content: await Translate('❌ | An error occurred while changing the nickname.', inter.guild.id), ephemeral: true });
        }
    }
};