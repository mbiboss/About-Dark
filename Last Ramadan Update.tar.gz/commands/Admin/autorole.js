const { ApplicationCommandOptionType, PermissionsBitField, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { Translate } = require('../../process_tools');

// Function to update autorole settings
function updateAutoroleSettings(guildId, roleId) {
    const settingsPath = path.join(__dirname, '../../serverSettings.json');
    let settings = fs.existsSync(settingsPath)
        ? JSON.parse(fs.readFileSync(settingsPath, 'utf-8'))
        : {};

    settings[guildId] = settings[guildId] || {};
    settings[guildId]['autoRoleId'] = roleId;

    fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2), 'utf-8');
}

module.exports = {
    name: 'autorole',
    description: 'Set a role to automatically assign to new members.',
    permissions: PermissionsBitField.Flags.Administrator, // Require Administrator permission
    options: [
        {
            name: 'role',
            description: 'The role to assign to new members',
            type: ApplicationCommandOptionType.Role,
            required: true,
        }
    ],

    async execute({ inter }) {
        try {
            // Ensure the command is only used by administrators
            if (!inter.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                return inter.reply({ content: await Translate('<❌> | Only administrators can use this command.'), ephemeral: true });
            }

            const guildId = inter.guild.id;
            const role = inter.options.getRole('role');

            // Ensure the bot has permission to manage roles
            if (!inter.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                return inter.editReply(await Translate('<❌> | I don\'t have permission to manage roles.'));
            }

            // Ensure the bot's highest role is higher than the role to assign
            if (role.position >= inter.guild.members.me.roles.highest.position) {
                return inter.editReply(await Translate('<❌> | I can\'t assign this role because it\'s higher than my highest role.'));
            }

            // Update the autorole settings
            updateAutoroleSettings(guildId, role.id);

            const successEmbed = new EmbedBuilder()
                .setColor('#00FF00')
                .setDescription(await Translate(`✅ Autorole has been set to **${role.name}**. New members will receive this role upon joining.`));

            inter.editReply({ embeds: [successEmbed] });

        } catch (error) {
            console.error('Error setting autorole:', error);
            inter.editReply(await Translate('<❌> | An error occurred while setting the autorole.'));
        }
    }
};