const { ApplicationCommandOptionType, PermissionsBitField, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { Translate, verifyLang } = require('../../process_tools'); // Importing verifyLang and Translate from process_tools

const settingsFilePath = path.join(__dirname, '../../serverSettings.json');

module.exports = {
    name: 'changelanguage',
    description: 'Change the bot language for translations.',
    permissions: PermissionsBitField.Flags.Administrator, // Require Administrator permission
    options: [
        {
            name: 'language',
            description: 'Enter the new language code (e.g., en, es, fr)',
            type: ApplicationCommandOptionType.String,
            required: true
        }
    ],

    async execute({ inter }) {
        try {
            // Ensure the interaction is deferred before replying to it
            if (!inter.deferred && !inter.replied) {
                await inter.deferReply({ ephemeral: true });
            }

            const newLang = inter.options.getString('language');
            const guildId = inter.guild.id;

            // Verify the new language code
            if (!verifyLang(newLang)) {
                return inter.editReply(await Translate('❌ | Invalid language code.', guildId));
            }

            // Load the server settings file
            let serverSettings = {};
            if (fs.existsSync(settingsFilePath)) {
                serverSettings = JSON.parse(fs.readFileSync(settingsFilePath, 'utf-8'));
            }

            // Update the language for the current server
            if (!serverSettings[guildId]) {
                serverSettings[guildId] = {};
            }
            serverSettings[guildId].language = newLang;

            // Save the updated server settings to the file
            fs.writeFileSync(settingsFilePath, JSON.stringify(serverSettings, null, 2));

            const embed = new EmbedBuilder()
                .setColor('#00FF00') // Use a valid hex color code for green
                .setDescription(await Translate(`✅ | Language has been changed to **${newLang}** for this server.`, guildId));

            await inter.editReply({ embeds: [embed] });
        } catch (error) {
            console.error('Error executing command changelanguage:', error);
            if (!inter.replied) {
                await inter.editReply('❌ | An error occurred while executing the command.');
            }
        }
    }
};