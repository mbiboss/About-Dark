const { ApplicationCommandOptionType, PermissionsBitField, EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'ban',
    description: 'Ban or unban a user from the server.',
    permissions: PermissionsBitField.Flags.BanMembers, // Require BanMembers permission
    options: [
        {
            name: 'action',
            description: 'Specify whether to ban or unban the user',
            type: ApplicationCommandOptionType.String,
            required: true,
            choices: [
                { name: 'Ban', value: 'ban' },
                { name: 'Unban', value: 'unban' }
            ]
        },
        {
            name: 'user',
            description: 'The user to ban or unban',
            type: ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: 'reason',
            description: 'Reason for the ban/unban (optional)',
            type: ApplicationCommandOptionType.String,
            required: false
        }
    ],

    async execute({ inter }) {
        try {
            const action = inter.options.getString('action');
            const user = inter.options.getUser('user');
            const reason = inter.options.getString('reason') || 'No reason provided';

            // Ensure the bot has permission to ban members
            if (!inter.guild.members.me.permissions.has(PermissionsBitField.Flags.BanMembers)) {
                return inter.editReply(await Translate('<❌> | I do not have permission to ban/unban members.'));
            }

            if (action === 'ban') {
                // Fetch the member to ban
                const member = await inter.guild.members.fetch(user.id).catch(() => null);

                if (!member) {
                    return inter.editReply(await Translate(`<❌> | Could not find ${member.displayName} in this server.`));
                }

                // Self-ban check
                if (member.id === inter.member.id) {
                    return inter.editReply(await Translate('<❌> | You cannot ban yourself.'));
                }

                // Owner ban check
                if (member.id === inter.guild.ownerId) {
                    return inter.editReply(await Translate('<❌> | You cannot ban the server owner.'));
                }

                // Ensure the administrator's role is higher than the member's role
                if (member.roles.highest.position >= inter.member.roles.highest.position && inter.guild.ownerId !== inter.member.id) {
                    return inter.editReply(await Translate('<❌> | You cannot ban this user because they have a higher or equal role.'));
                }

                // Check if the member is bannable by the bot
                if (!member.bannable) {
                    return inter.editReply(await Translate('<❌> | I cannot ban this user. They might have higher roles than me.'));
                }

                // Ban the member
                await member.ban({ reason });

                const embed = new EmbedBuilder()
                    .setColor('ff0000')
                    .setDescription(await Translate(`✅ | Successfully banned ${member.displayName}! Reason: ${reason}`));

                // Send the ban message to the channel where the command was executed
                await inter.channel.send({ embeds: [embed] });

                // Optionally, send an ephemeral confirmation to the user who executed the command
                return inter.editReply(await Translate(`✅ | You have successfully banned ${user.tag}.`));
                
            } else if (action === 'unban') {
                // Unban the user by ID
                const bannedUsers = await inter.guild.bans.fetch();
                const bannedUser = bannedUsers.get(user.id);

                if (!bannedUser) {
                    return inter.editReply(await Translate(`<❌> | ${member.displayName} is not banned.`));
                }

                // Unban the user
                await inter.guild.bans.remove(user.id, reason);

                const embed = new EmbedBuilder()
                    .setColor('00ff00')
                    .setDescription(await Translate(`✅ | Successfully unbanned ${member.displayName}! Reason: ${reason}`));

                // Send the unban message to the channel where the command was executed
                await inter.channel.send({ embeds: [embed] });

                // Optionally, send an ephemeral confirmation to the user who executed the command
                return inter.editReply(await Translate(`✅ | You have successfully unbanned ${member.displayName}.`));
            } else {
                return inter.editReply(await Translate('<❌> | Invalid action specified.'));
            }
        } catch (error) {
            console.error('Error in /ban command:', error);
            return inter.editReply(await Translate('<❌> | An error occurred while processing the ban command.'));
        }
    }
};