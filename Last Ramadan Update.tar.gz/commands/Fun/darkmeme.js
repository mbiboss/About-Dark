const { EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'darkmeme',
    description: 'Get a random dark humor meme from Reddit.😈',
    async execute({ inter }) {
        try {
            // Defer the reply to avoid interaction timeouts
            if (!inter.deferred && !inter.replied) {
                await inter.deferReply({ flags: 64 });
            }

            // Using dynamic import for fetch
            const fetch = await import('node-fetch');
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 10000); // Extend timeout to 10 seconds

            // Fetching meme data from r/darkmemes
            const response = await fetch.default('https://www.reddit.com/r/darkmemes/hot.json?limit=100', {
                signal: controller.signal,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
                }
            });
            clearTimeout(timeout);

            const data = await response.json();

            // Checking if memes data is valid
            if (!data || !data.data || !data.data.children) {
                return inter.editReply({
                    content: await Translate('❌ | Oops! Could not fetch a dark meme. Try again later. 😈', inter.guild.id)
                });
            }

            // Filtering out posts that are not images
            const memePosts = data.data.children.filter(post => post.data.post_hint === 'image');
            const randomMeme = memePosts[Math.floor(Math.random() * memePosts.length)];

            if (!randomMeme || !randomMeme.data || !randomMeme.data.url) {
                return inter.editReply({
                    content: await Translate('❌ | Oops! Dark meme not found. Try again later. ⚡', inter.guild.id)
                });
            }

            const meme = randomMeme.data;

            // Creating the embed for the meme
            const embed = new EmbedBuilder()
                .setColor('#000000') // Dark color for dark memes
                .setTitle(await Translate(meme.title, inter.guild.id))
                .setImage(meme.url)
                .setFooter({
                    text: await Translate('Meme courtesy of DarK Host 🖤', inter.guild.id),
                    iconURL: 'https://i.postimg.cc/kGQkF9LH/felix-acidcat.gif' // Optional icon
                })
                .setTimestamp(); // Adding a timestamp for extra flair

            // Sending the meme embed to the channel
            await inter.editReply({
                embeds: [embed]
            });

        } catch (error) {
            console.error('Error fetching dark meme:', error);

            // Handling errors gracefully
            if (!inter.deferred && !inter.replied) {
                // If the interaction was not deferred or replied, send an error reply
                await inter.reply({
                    content: await Translate('❌ | An unexpected error occurred. Please try again later. 😥', inter.guild.id),
                    flags: 64 // Ensure the error message is visible
                });
            } else {
                // If the interaction was deferred or replied, edit the reply with the error message
                await inter.editReply({
                    content: await Translate('❌ | An unexpected error occurred. Please try again later. 😥', inter.guild.id)
                });
            }
        }
    }
};