const { EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');
const banglaJokes = require('./banglaJokes.json');

module.exports = {
    name: 'joke',
    description: 'Get a random joke.😂',
    options: [
        {
            name: 'language',
            description: 'Select the language for the joke',
            type: 3, // STRING type
            required: false,
            choices: [
                { name: 'English', value: 'en' },
                { name: 'Spanish', value: 'es' },
                { name: 'German', value: 'de' },
                { name: 'Bangla', value: 'bn' }
            ]
        }
    ],
    async execute({ inter }) {
        try {
            // Check if the interaction is valid before deferring the reply
            if (!inter.deferred && !inter.replied) {
                await inter.deferReply({ flags: 64 });
            }

            const language = inter.options.getString('language') || 'en';

            const fetch = await import('node-fetch');
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 10000); // Extend timeout to 10 seconds

            let jokeText;

            if (language === 'bn') {
                // Fetch a random Bangla joke from the local JSON file
                const randomIndex = Math.floor(Math.random() * banglaJokes.jokes.length);
                jokeText = banglaJokes.jokes[randomIndex];
            } else {
                const response = await fetch.default(`https://v2.jokeapi.dev/joke/Any?lang=${language}`, { signal: controller.signal });
                clearTimeout(timeout);

                const data = await response.json();

                // Checking if joke data is valid
                if (!data || (!data.joke && (!data.setup || !data.delivery))) {
                    return inter.editReply({
                        content: await Translate('❌ | Oops! Could not fetch a joke. Try again later. 😂', inter.guild.id)
                    });
                }

                if (data.type === 'single') {
                    jokeText = data.joke;
                } else {
                    jokeText = `${data.setup}\n\n${data.delivery}`;
                }
            }

            // Creating the embed for the joke
            const embed = new EmbedBuilder()
                .setColor('#00FF00') // Use a bright color for jokes
                .setTitle(await Translate('Here\'s a joke for you!', inter.guild.id))
                .setDescription(await Translate(jokeText, inter.guild.id))
                .setFooter({
                    text: await Translate('Brought to you by DarK Host 😂', inter.guild.id),
                    iconURL: 'https://i.postimg.cc/kGQkF9LH/felix-acidcat.gif' // Optional icon
                })
                .setTimestamp(); // Adding a timestamp for extra flair

            // Sending the joke embed to the channel
            await inter.editReply({
                embeds: [embed]
            });

        } catch (error) {
            console.error('Error fetching joke:', error);

            // Handling errors gracefully
            if (!inter.deferred && !inter.replied) {
                // If the interaction was not deferred or replied, send an error reply
                await inter.reply({
                    content: await Translate('❌ | An unexpected error occurred. Please try again later. 😥', inter.guild.id),
                    flags: 64 // Ensure the error message is visible
                });
            } else {
                // If the interaction was deferred or replied, edit the reply with the error message
                await inter.editReply({
                    content: await Translate('❌ | An unexpected error occurred. Please try again later. 😥', inter.guild.id)
                });
            }
        }
    }
};