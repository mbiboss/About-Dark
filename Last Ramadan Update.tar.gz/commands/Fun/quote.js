const { EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'quote',
    description: 'Get a random inspirational quote.✨',
    async execute({ inter }) {
        try {
            // Defer the reply to avoid interaction timeouts
            if (!inter.deferred && !inter.replied) {
                await inter.deferReply();
            }

            const fetch = await import('node-fetch');
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 10000); // Extend timeout to 10 seconds

            try {
                const response = await fetch.default('https://api.quotable.io/random', { signal: controller.signal });
                clearTimeout(timeout);

                const data = await response.json();

                // Checking if quote data is valid
                if (!data || !data.content) {
                    throw new Error('Invalid quote data');
                }

                // Creating the embed for the quote
                const embed = new EmbedBuilder()
                    .setColor('#FFA500') // Use a warm color for quotes
                    .setTitle(await Translate('Here\'s a quote for you!', inter.guild.id))
                    .setDescription(await Translate(`"${data.content}" - ${data.author}`, inter.guild.id))
                    .setFooter({
                        text: await Translate('Quote courtesy of DarK Host ✨', inter.guild.id),
                        iconURL: 'https://i.postimg.cc/kGQkF9LH/felix-acidcat.gif' // Optional icon
                    })
                    .setTimestamp(); // Adding a timestamp for extra flair

                // Sending the quote embed to the channel
                await inter.editReply({
                    embeds: [embed]
                });

            } catch (err) {
                // Fallback to another API in case of error
                const fallbackResponse = await fetch.default('https://zenquotes.io/api/random', { signal: controller.signal });
                clearTimeout(timeout);

                const fallbackData = await fallbackResponse.json();

                if (!fallbackData || !fallbackData[0] || !fallbackData[0].q) {
                    throw new Error('Invalid fallback quote data');
                }

                // Creating the embed for the fallback quote
                const fallbackEmbed = new EmbedBuilder()
                    .setColor('#FFA500') // Use a warm color for quotes
                    .setTitle(await Translate('Here\'s a fallback quote for you!', inter.guild.id))
                    .setDescription(await Translate(`"${fallbackData[0].q}" - ${fallbackData[0].a}`, inter.guild.id))
                    .setFooter({
                        text: await Translate('Quote courtesy of DarK Host ✨', inter.guild.id),
                        iconURL: 'https://i.postimg.cc/kGQkF9LH/felix-acidcat.gif' // Optional icon
                    })
                    .setTimestamp(); // Adding a timestamp for extra flair

                // Sending the fallback quote embed to the channel
                await inter.editReply({
                    embeds: [fallbackEmbed]
                });
            }

        } catch (error) {
            console.error('Error fetching quote:', error);

            // Handling errors gracefully
            if (!inter.deferred && !inter.replied) {
                // If the interaction was not deferred or replied, send an error reply
                await inter.reply({
                    content: await Translate('❌ | An unexpected error occurred. Please try again later. 😥', inter.guild.id),
                    flags: 64 // Ensure the error message is visible
                });
            } else {
                // If the interaction was deferred or replied, edit the reply with the error message
                await inter.editReply({
                    content: await Translate('❌ | An unexpected error occurred. Please try again later. 😥', inter.guild.id)
                });
            }
        }
    }
};