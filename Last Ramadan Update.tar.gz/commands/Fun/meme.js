const { EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'meme',
    description: 'Get a random meme.😂',
    async execute({ inter }) {
        // Defer the reply to avoid interaction timeouts
        if (!inter.deferred && !inter.replied) {
            await inter.deferReply({ ephemeral: false }); // Ensure the reply is not ephemeral
        }

        try {
            // Using dynamic import for fetch
            const fetch = await import('node-fetch');
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 10000); // Extend timeout to 10 seconds

            // Fetching meme data
            const response = await fetch.default('https://api.imgflip.com/get_memes', { signal: controller.signal });
            clearTimeout(timeout);

            const data = await response.json();

            // Checking if memes data is valid
            if (!data || !data.data || !data.data.memes) {
                return inter.editReply({
                    content: await Translate('❌ | Oops! Could not fetch a meme. Try again later. 🐱‍🏍', inter.guild.id)
                });
            }

            // Picking a random meme
            const randomMeme = data.data.memes[Math.floor(Math.random() * data.data.memes.length)];

            if (!randomMeme || !randomMeme.url) {
                return inter.editReply({
                    content: await Translate('❌ | Oops! Meme not found. Try again later. ⚡', inter.guild.id)
                });
            }

            // Creating the embed for the meme
            const embed = new EmbedBuilder()
                .setColor('#FF5733') // Using a vibrant color
                .setTitle(await Translate(randomMeme.name, inter.guild.id))
                .setImage(randomMeme.url)
                .setFooter({
                    text: await Translate('Meme courtesy of DarK Host 🖤', inter.guild.id),
                    iconURL: 'https://i.postimg.cc/kGQkF9LH/felix-acidcat.gif' // Optional icon
                })
                .setTimestamp(); // Adding a timestamp for extra flair

            // Sending the meme embed to the channel
            await inter.editReply({
                embeds: [embed]
            });

        } catch (error) {
            console.error('Error fetching meme:', error);

            // Handling errors gracefully
            await inter.editReply({
                content: await Translate('❌ | An unexpected error occurred. Please try again later. 😥', inter.guild.id)
            });
        }
    }
};