const { EmbedBuilder } = require('discord.js');
const ms = require('ms');
const { Translate } = require('../../process_tools');
const imgids = require('../../imgurl'); // Import all images as a single object

const pingMessages = [
    "Pong! 🏓 The bot's speed is <{ping}ms 🛰️>.",
    "Boing! The bot is as fast as a ninja on roller skates. Speed: <{ping}ms 🏎️>.",
    "Ping! 📡 The server just hit <{ping}ms 🏓> – faster than a cheetah on caffeine! 🐆",
    "Ping-pong! 🏓 Bot response time: <{ping}ms 🌐>. Your connection is like a bullet train! 🚅",
    "Whew! ⚡ Bot is lightning fast! Response: <{ping}ms 🔋>. Last pulse was <{lastPulse}>.",
    "Ping-a-ling! 🛎️ The bot's heartbeat is at <{ping}ms 🕹️>. Last pulse was <{lastPulse}>.",
    "Hold on to your hats! 🎩 The ping just came in at <{ping}ms 🏁>. More precise than a Swiss watch! 🕰️",
    "Whoa! Did you feel that? ⚡ Ping speed: <{ping}ms 🚀>. This bot could outrun a rocket! 🚀",
    "Ping Pong Master! 🏓 The bot is serving at <{ping}ms ⏱️>. I bet you can't beat that! 🏆",
    "I’m fast like a squirrel with espresso! ☕ Speed: <{ping}ms 🌪️>. Last heartbeat was <{lastPulse}>. 🐿️"
];

module.exports = {
    name: 'ping',
    description: '🏓 Check the bot latency.',
    async execute({ client, inter }) {
        await inter.editReply("Ping-a-ling! Calculating...");

        const ping = Math.round(client.ws.ping);
        const lastPulse = ms(Date.now() - client.ws.shards.first().lastPingTimestamp, { long: true });
        const randomMessage = pingMessages[Math.floor(Math.random() * pingMessages.length)];

        const response = await Translate(randomMessage);

        const finalResponse = response
            .replace("{ping}", ping)
            .replace("{lastPulse}", lastPulse);

        // Create an embed with the icon at the beginning
        const pingEmbed = new EmbedBuilder()
            .setColor('#00FF00') // Green color
            .setDescription(`[🛰️] ${finalResponse}`)
            .setThumbnail(imgids.img1) // Use img4 as the thumbnail
            .setImage(imgids.img3) // Use img3 as the large image
        // Send the embed
        await inter.editReply({ embeds: [pingEmbed] });
    }
};