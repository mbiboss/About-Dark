const { EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'weather',
    description: 'Get detailed weather information for any location 🌦️',
    options: [
        {
            name: 'location',
            description: '🌍 City name, zip code, or coordinates',
            type: 3,
            required: true
        }
    ],
    async execute({ inter }) {
        try {
            if (!inter.deferred && !inter.replied) {
                await inter.deferReply({ ephemeral: false });
            }

            const location = inter.options.getString('location');
            const encodedLocation = encodeURIComponent(location);
            const fetch = await import('node-fetch');

            const geoResponse = await fetch.default(`https://geocoding-api.open-meteo.com/v1/search?name=${encodedLocation}`);
            const geoData = await geoResponse.json();

            if (!geoData?.results?.length) {
                return await inter.editReply({
                    content: await Translate(`\`\`\`❌ Couldn't find "${location}". Check spelling or try another location.\`\`\``, inter.guild.id),
                    flags: 'Ephemeral'
                });
            }

            const { latitude, longitude, name, country_code, timezone } = geoData.results[0];

            const weatherParams = new URLSearchParams({
                latitude,
                longitude,
                current: ['temperature_2m', 'apparent_temperature', 'weathercode', 'windspeed_10m', 'winddirection_10m', 'relativehumidity_2m', 'precipitation', 'uv_index', 'is_day'].join(','),
                timezone,
                forecast_days: 1
            });

            const weatherResponse = await fetch.default(`https://api.open-meteo.com/v1/forecast?${weatherParams}`);
            const weatherData = await weatherResponse.json();

            if (!weatherData.current) {
                return await inter.editReply({
                    content: await Translate('\`\`\`❌ Weather service unavailable. Please try again later.\`\`\`', inter.guild.id),
                    flags: 'Ephemeral'
                });
            }

            const current = weatherData.current;
            const weatherInfo = {
                condition: this.getWeatherCondition(current.weathercode, current.is_day),
                color: this.getWeatherColor(current.weathercode),
                temperature: `\`\`\`${current.temperature_2m}°C\`\`\``,
                feelsLike: `\`\`\`${current.apparent_temperature}°C\`\`\``,
                wind: `\`\`\`${current.windspeed_10m} km/h\`\`\``,
                humidity: `\`\`\`${current.relativehumidity_2m}%\`\`\``,
                precipitation: `\`\`\`${current.precipitation} mm\`\`\``,
                uvIndex: `\`\`\`${current.uv_index}\`\`\``,
                windDirection: `\`\`\`${this.getWindDirection(current.winddirection_10m)}\`\`\``,
                localTime: `\`\`\`${new Date(current.time).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}\`\`\``
            };

            const weatherEmbed = new EmbedBuilder()
                .setColor(weatherInfo.color)
                .setTitle(`${name}, ${this.getCountryName(country_code)} ${this.getCountryFlag(country_code)}`)
                .setDescription(`\`\`\`${weatherInfo.condition}\`\`\``)
                .setThumbnail(`https://flagsapi.com/${country_code}/flat/64.png`)
                .setImage('https://i.postimg.cc/MTvjDs38/standard.gif')
                .addFields(
                    { name: '🌡 Temperature', value: weatherInfo.temperature, inline: true },
                    { name: '🌬 Wind', value: weatherInfo.wind, inline: true },
                    { name: '💧 Humidity', value: weatherInfo.humidity, inline: true },
                    { name: '🎐 Direction', value: weatherInfo.windDirection, inline: true },
                    { name: '🌡 Feels Like', value: weatherInfo.feelsLike, inline: true },
                    { name: '🕒 Local Time', value: weatherInfo.localTime, inline: true },
                    { name: '🌧 Precipitation', value: weatherInfo.precipitation, inline: true },
                    { name: '☀ UV Index', value: `\`\`\`${this.getUVIndexLevel(weatherInfo.uvIndex)}\`\`\``, inline: true }
                )
                .setFooter({
                    text: await Translate('Powered by DarK Host 🌤️', inter.guild.id),
                    iconURL: 'https://i.postimg.cc/kGQkF9LH/felix-acidcat.gif'
                })
                .setTimestamp();

            await inter.editReply({ embeds: [weatherEmbed] });

        } catch (error) {
            console.error('Weather command error:', error);
            const errorMessage = '\`\`\`❌ Failed to fetch weather data. Please try again later.\`\`\`';

            if (inter.deferred || inter.replied) {
                await inter.editReply({ content: await Translate(errorMessage, inter.guild.id), flags: 'Ephemeral' });
            } else {
                await inter.reply({ content: await Translate(errorMessage, inter.guild.id), flags: 'Ephemeral' });
            }
        }
    },

    getWeatherCondition(code, isDay) {
        const conditions = {
            0: isDay ? 'Clear Sky ☀️' : 'Starry Night 🌌',
            1: isDay ? 'Mostly Sunny 🌤' : 'Partly Cloudy 🌥',
            2: 'Partly Cloudy ⛅',
            3: 'Overcast ☁️',
            45: 'Fog 🌫️',
            48: 'Freezing Fog ❄️🌫️',
            51: 'Light Drizzle 🌦️',
            53: 'Moderate Drizzle 🌧️',
            55: 'Heavy Drizzle 🌧️',
            56: 'Freezing Drizzle 🌨️',
            57: 'Heavy Freezing Drizzle ❄️🌧️',
            61: 'Light Rain 🌦️',
            63: 'Moderate Rain 🌧️',
            65: 'Heavy Rain 🌧️💦',
            66: 'Ice Pellets 🧊',
            67: 'Heavy Ice Pellets ❄️🧊',
            71: 'Light Snow 🌨️',
            73: 'Moderate Snow ❄️',
            75: 'Heavy Snow ❄️⛄',
            77: 'Snow Grains 🌨️',
            80: 'Light Showers 🌦️',
            81: 'Moderate Showers 🌧️',
            82: 'Violent Showers ⛈️',
            85: 'Snow Showers 🌨️',
            86: 'Heavy Snow Showers ❄️🌨️',
            95: 'Thunderstorm ⚡',
            96: 'Storm with Hail ⚡🧊',
            99: 'Severe Thunderstorm ⚡🌪️'
        };
        return conditions[code] || 'Unknown Conditions';
    },

    getWeatherColor(code) {
        const colors = {
            sunny: '#FFD700',
            cloudy: '#A9A9A9',
            rainy: '#1E90FF',
            snowy: '#FFFFFF',
            stormy: '#4B0082',
            default: '#0099FF'
        };

        if (code >= 0 && code <= 3) return code === 0 ? colors.sunny : colors.cloudy;
        if (code >= 45 && code <= 67) return colors.rainy;
        if (code >= 71 && code <= 86) return colors.snowy;
        if (code >= 95 && code <= 99) return colors.stormy;
        return colors.default;
    },

    getWindDirection(degrees) {
        const directions = ['↓ N', '↙ NE', '← E', '↖ SE', '↑ S', '↗ SW', '→ W', '↘ NW'];
        return directions[Math.round(degrees % 360 / 45) % 8];
    },

    getUVIndexLevel(uvIndex) {
        const levels = ['Low ☀️', 'Moderate 🌤️', 'High 🌞', 'Very High 🔥', 'Extreme ☠️'];
        return levels[Math.min(Math.floor(uvIndex / 3), 4)];
    },

    getCountryFlag(code) {
        return String.fromCodePoint(...[...code.toUpperCase()].map(c => 127397 + c.charCodeAt()));
    },

    getCountryName(code) {
        const regionNames = new Intl.DisplayNames(['en'], { type: 'region' });
        return regionNames.of(code) || code;
    }
};