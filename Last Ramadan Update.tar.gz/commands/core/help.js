const { EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');
const imgids = require('../../imgurl'); // Import all image IDs as a single object

module.exports = {
    name: 'help',
    description: "Unleash the beat! 🎶",
    showHelp: false,

    async execute({ client, inter }) {
        const embed = new EmbedBuilder()
            .setColor('#FF0000') // YouTube's brand color (red) for a thematic look
            .setAuthor({
                name: `${client.user.username} Help Menu`,
                iconURL: client.user.displayAvatarURL({ size: 1024, dynamic: true })
            })
            .setTitle(await Translate('🎵 **Music Bot Commands** 🎵'))
            .setDescription(await Translate('📜 **Here is a list of all available commands and their usage:**'))
            .addFields(
                { 
                    name: '🎶 **Music Playback**', 
                    value: '🔸 **`/play <song name or URL>`** - 🎧 Play a song from YouTube.\n' +
                           '🔸 **`/play <playlist URL>`** - 📃 Play a YouTube playlist.\n' +
                           '🔸 **`/autoplay`** - 🔁 Toggle autoplay with random genres when the queue is empty.\n' +
                           '🔸 **`/playnext <song name or URL>`** - ⏭️ Queue a song to play next.\n' +
                           '🔸 **`/search <query>`** - 🔍 Search for a song on YouTube.\n' +
                           '🔸 **`/skip`** - ⏩ Skip the current song.\n' +
                           '🔸 **`/skipto <number>`** - 🎯 Skip to a specific song in the queue.\n' +
                           '🔸 **`/back`** - ⏮️ Play the previous song.\n' +
                           '🔸 **`/stop`** - 🛑 Stop the music and clear the queue.\n' +
                           '🔸 **`/pause`** - ⏸️ Pause the current song.\n' +
                           '🔸 **`/resume`** - ▶️ Resume the paused song.'
                },
                { 
                    name: '📜 **Queue Management**', 
                    value: '🔸 **`/queue`** - 📜 Show the current queue.\n' +
                           '🔸 **`/remove <number>`** - ❌ Remove a song from the queue.\n' +
                           '🔸 **`/clear`** - 🧹 Clear the entire queue.\n' +
                           '🔸 **`/shuffle`** - 🔀 Shuffle the queue.\n' +
                           '🔸 **`/jump <number>`** - 🎤 Jump to a specific song in the queue.'
                },
                { 
                    name: '🔁 **Loop & Seek**', 
                    value: '🔸 **`/loop <queue|song|off>`** - 🔄 Enable or disable looping.\n' +
                           '🔸 **`/seek <time>`** - ⏩ Seek to a specific time in the current song.'
                },
                { 
                    name: '🎛 **Audio Settings**', 
                    value: '🔸 **`/volume <1-100>`** - 🔊 Adjust the volume.\n' +
                           '🔸 **`/filter <bassboost|nightcore|etc>`** - 🎚️ Apply an audio filter.'
                },
                { 
                    name: '📖 **Lyrics & Info**', 
                    value: '🔸 **`/nowplaying`** - ℹ️ Show details of the current song.\n' +
                           '🔸 **`/lyrics <song>`** - 🎼 Get the lyrics for the current track.\n' +
                           '🔸 **`/syncedlyrics`** - 🎶 Get synced lyrics (if available).\n' +
                           '🔸 **`/history`** - 🕒 View recently played songs.'
                },
                { 
                    name: '🎚 **Advanced Controls**', 
                    value: '🔸 **`/controller`** - 🎛️ Send a music control panel to the channel.\n' +
                           '🔸 **`/save`** - 💾 Save the current song to your favorites.\n' +
                           '🔸 **`/join`** - ➕ Join the voice channel.\n' +
                           '🔸 **`/leave`** - ➖ Leave the voice channel.'
                },
                { 
                    name: '⚙ **General Commands**', 
                    value: '🔸 **`/ping`** - 🏓 Check the bot\'s latency.\n' +
                           '🔸 **`/help`** - 📋 Display this help menu.'
                }
            )
            .setThumbnail(imgids.img4) // Use img4 as the thumbnail
            .setImage(imgids.img3) // Use img3 as the large image
            .setTimestamp()
            .setFooter({
                text: await Translate('🎶 Music comes first - Crafted with ❤️ by MBI_BOSS'),
                iconURL: imgids.img1 // Use img1 as the footer icon
            });

        await inter.editReply({ embeds: [embed] });
    }
};