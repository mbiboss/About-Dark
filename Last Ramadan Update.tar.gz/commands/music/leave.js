const { EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'leave',
    description: '➖ Leave the voice channel.',
    voiceChannel: true,

    async execute({ inter }) {
        const queue = useQueue(inter.guild);
        const embed = new EmbedBuilder().setColor('#2f3136');

        try {
            if (!queue || !queue.node) {
                embed.setAuthor({ name: await Translate(`Not connected to any voice channel! <❌>`) });
                return inter.editReply({ embeds: [embed] });
            }

            // Correct method for v6+
            queue.delete();
            embed.setAuthor({ name: await Translate(`Successfully disconnected! <✅>`) });
        } catch (error) {
            console.error('Leave Error:', error);
            embed.setAuthor({ name: await Translate(`Disconnection failed: ${error.message} <❌>`) });
        }

        return inter.editReply({ embeds: [embed] });
    }
}