const { useQueue, QueryType, QueueRepeatMode, useMainPlayer } = require('discord-player');
const { EmbedBuilder } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'autoplay',
    description: '🔁 Toggle autoplay with random genres when the queue is empty.',
    voiceChannel: true,

    async execute({ inter, client }) {
        const player = useMainPlayer(); // Initialize the player
        const queue = useQueue(inter.guild);
        const channel = inter.member.voice.channel;
        const embed = new EmbedBuilder().setColor('#2f3136');

        if (!channel) {
            embed.setAuthor({ name: await Translate(`You need to be in a voice channel! <❌>`) });
            return inter.editReply({ embeds: [embed] });
        }

        // List of random genres/queries to play
        const randomGenres = [
            'Bangla music',
            'lofi mashup',
            'sad songs playlist',
            'EDM remix',
            'bollywood remix',
            'pop hits',
            'chill music',
            'classic rock',
            'jazz playlist',
            'hip hop mix',
            'funk',
            'phonk',
            'bangla flok',
            'bangla lofi'
        ];

        try {
            // If no music is playing, start with a random genre
            if (!queue || !queue.isPlaying()) {
                const randomQuery = randomGenres[Math.floor(Math.random() * randomGenres.length)];
                const { track } = await player.play(channel, randomQuery, {
                    requestedBy: inter.member,
                    searchEngine: QueryType.AUTO,
                    nodeOptions: {
                        metadata: {
                            channel: inter.channel,
                            client: inter.guild.members.me,
                            requestedBy: inter.user.username
                        },
                        volume: client.config.opt.volume || 50, // Default volume if not set
                        leaveOnEnd: false,
                        leaveOnEmpty: false
                    }
                });

                // Enable autoplay for the queue
                const newQueue = useQueue(inter.guild);
                newQueue.setRepeatMode(QueueRepeatMode.AUTOPLAY);

                embed.setAuthor({ name: await Translate(`Autoplay started with <${track.title}>! <🔁>`) });
                return inter.editReply({ embeds: [embed] });
            }

            // If music is already playing, toggle autoplay
            const currentMode = queue.repeatMode;
            const success = currentMode === QueueRepeatMode.AUTOPLAY
                ? queue.setRepeatMode(QueueRepeatMode.OFF)
                : queue.setRepeatMode(QueueRepeatMode.AUTOPLAY);

            embed.setAuthor({ name: currentMode === QueueRepeatMode.AUTOPLAY
                ? await Translate(`Autoplay disabled <❌>`)
                : await Translate(`Autoplay enabled! Adding similar songs <🔁>`)
            });
            return inter.editReply({ embeds: [embed] });
        } catch (error) {
            console.error('Autoplay Error:', error);
            embed.setAuthor({ name: await Translate(`Failed to start autoplay: ${error.message} <❌>`) });
            return inter.editReply({ embeds: [embed] });
        }
    }
};