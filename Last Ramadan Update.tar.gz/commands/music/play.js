const { QueryType, useMainPlayer } = require('discord-player');
const { ApplicationCommandOptionType, EmbedBuilder, PermissionsBitField, ActivityType } = require('discord.js');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'play',
    description:("🎧 Play a song from YouTube or a URL."),
    voiceChannel: true,
    options: [
        {
            name: 'song',
            description:('The song you want to play'),
            type: ApplicationCommandOptionType.String,
            required: true,
        }
    ],

    async execute({ inter, client }) {
        const player = useMainPlayer();

        const song = inter.options.getString('song');
        const res = await player.search(song, {
            requestedBy: inter.member,
            searchEngine: QueryType.AUTO
        });

        let defaultEmbed = new EmbedBuilder().setColor('#2f3136');

        if (!res?.tracks.length) {
            defaultEmbed.setAuthor({ name: await Translate(`No results found... try again? <❌>`) });
            return inter.editReply({ embeds: [defaultEmbed] });
        }

        try {
            const { track } = await player.play(inter.member.voice.channel, song, {
                nodeOptions: {
                    metadata: {
                        channel: inter.channel
                    },
                    volume: client.config.opt.volume,
                    leaveOnEmpty: client.config.opt.leaveOnEmpty,
                    leaveOnEmptyCooldown: client.config.opt.leaveOnEmptyCooldown,
                    leaveOnEnd: client.config.opt.leaveOnEnd,
                    leaveOnEndCooldown: client.config.opt.leaveOnEndCooldown,
                }
            });

            // Change voice channel status and set random bot status
            if (inter.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
                const voiceChannel = inter.member.voice.channel;
                await voiceChannel.setBitrate(96000);
                await voiceChannel.setUserLimit(10);

                // Array of possible status messages (20+ statuses)
                const statuses = [
                    `🎶 Jamming in ${voiceChannel.name}`,
                    `🎧 Rocking out in ${voiceChannel.name}`,
                    `🔊 Tuning in to ${voiceChannel.name}`,
                    `🎵 Playing tunes in ${voiceChannel.name}`,
                    `🎤 Singing along in ${voiceChannel.name}`,
                    `🎼 Enjoying the vibes in ${voiceChannel.name}`,
                    `🎙️ Broadcasting in ${voiceChannel.name}`,
                    `🎚️ Mixing tracks in ${voiceChannel.name}`,
                    `🎹 Performing live in ${voiceChannel.name}`,
                    `📻 Streaming in ${voiceChannel.name}`,
                    `🎷 Jazzy tunes in ${voiceChannel.name}`,
                    `🎸 Strumming chords in ${voiceChannel.name}`,
                    `🎺 Blowing tunes in ${voiceChannel.name}`,
                    `🎻 Fiddling in ${voiceChannel.name}`,
                    `🥁 Drumming in ${voiceChannel.name}`,
                    `🎺 Playing brass in ${voiceChannel.name}`,
                    `🎹 Keyboard magic in ${voiceChannel.name}`,
                    `🎸 Guitar solo in ${voiceChannel.name}`,
                    `🎤 Karaoke night in ${voiceChannel.name}`,
                    `🎧 DJ set in ${voiceChannel.name}`,
                    `🎶 Symphony in ${voiceChannel.name}`
                ];

                // Select a random status from the array
                const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];

                // Set the random status
                client.user.setActivity(randomStatus, { type: ActivityType.Listening });
            }

            defaultEmbed.setAuthor({ name: await Translate(`Loading <${track.title}> to the queue... <✅>`) });
            await inter.editReply({ embeds: [defaultEmbed] });
        } catch (error) {
            console.log(`Play error: ${error}`);
            defaultEmbed.setAuthor({ name: await Translate(`I can't join the voice channel... try again? <❌>`) });
            return inter.editReply({ embeds: [defaultEmbed] });
        }
    }
}