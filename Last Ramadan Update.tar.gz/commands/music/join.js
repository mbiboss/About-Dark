const { EmbedBuilder } = require('discord.js');
const { useMainPlayer } = require('discord-player');
const { Translate } = require('../../process_tools');

module.exports = {
    name: 'join',
    description: ' ➕ Join the voice channel.',
    voiceChannel: true,

    async execute({ inter }) {
        const player = useMainPlayer();
        const channel = inter.member.voice.channel;
        const embed = new EmbedBuilder().setColor('#2f3136');

        if (!channel) {
            embed.setAuthor({ name: await Translate(`You need to be in a voice channel! <❌>`) });
            return inter.editReply({ embeds: [embed] });
        }

        try {
            // New method for discord-player v6+
            await player.nodes.create(inter.guild, {
                metadata: {
                    channel: inter.channel,
                    client: inter.guild.members.me,
                    requestedBy: inter.user.username
                },
                selfDeaf: true,
                volume: 100,
                leaveOnEnd: false
            }).connect(channel);

            embed.setAuthor({ name: await Translate(`Joined ${channel.name} successfully! <✅>`) });
            return inter.editReply({ embeds: [embed] });
        } catch (error) {
            console.error('Join Error:', error);
            embed.setAuthor({ name: await Translate(`Failed to join: ${error.message} <❌>`) });
            return inter.editReply({ embeds: [embed] });
        }
    }
}