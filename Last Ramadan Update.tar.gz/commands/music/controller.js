const { ApplicationCommandOptionType, EmbedBuilder, PermissionsBitField } = require('discord.js');
const imgids = require('../../imgurl'); 

module.exports = {
    name: 'owner',
    description: 'Get detailed information about the bot owner.',
    permissions: PermissionsBitField.Flags.ViewChannel,
    options: [],
    async execute({ inter }) {
        const ownerName = 'MD ISMAIL FORAJI';
        const ownerDiscordName = '!        MBI BOSS';
        const ownerDiscordUsername = 'mbi_boss';
        const ownerDiscordTag = '**MBI BOSS**';
        const ownerAvatarURL = imgids.img5;
        const ownerDescription = '🌸 শূন্যের শূন্যতায় শূন্যস্থান শূন্য 🥀';
        const ownerJoinDate = new Date('2020-07-11');
        const ownerRoles = ['Admin', 'Developer'];
        const ownerPermissions = ['ADMINISTRATOR'];

        const embed = new EmbedBuilder()
            .setColor('#0000ff')
            .setTitle('📜 Bot Owner Information 📜')
            .setThumbnail(ownerAvatarURL)
            .setDescription(
                `🔗 Profile: [${ownerDiscordTag}](https://discord.com/users/731544517542674443)\n\n` +
                `\`\`\`🌟 Roles: ${ownerRoles.join(', ')}\`\`\``
            )
            .addFields(
                { name: '📛 Name', value: `\`\`\`${ownerName}\`\`\``, inline: true },
                { name: '🔖 Discord Name', value: `\`\`\`${ownerDiscordName}\`\`\``, inline: true },
                { name: '🔖 Discord Username', value: `\`\`\`${ownerDiscordUsername}\`\`\``, inline: true },
                { name: 'ℹ️ Description', value: `\`\`\`${ownerDescription}\`\`\``, inline: false },
                { name: '🛡️ Key Permissions', value: `\`\`\`${ownerPermissions.join(', ')}\`\`\``, inline: false },
                { name: '📆 Joined Discord', value: `<t:${Math.floor(ownerJoinDate.getTime() / 1000)}:R>`, inline: true }
            )
            .setFooter({
                text: '💌 Need any help? Feel free to send me a message!',
                iconURL: imgids.img1
            })
            .setTimestamp()
            .setImage(imgids.img3);

        // Make it visible to everyone
        await inter.reply({ embeds: [embed] }); 
    }
};