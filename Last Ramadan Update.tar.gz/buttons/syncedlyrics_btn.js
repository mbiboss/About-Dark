const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
const { Translate } = require('../process_tools');

module.exports = async ({ client, inter, queue }) => {
    try {
        // Your existing synced lyrics logic here
        const metadataThread = queue.metadata.lyricsThread;
        
        if (metadataThread && !metadataThread.archived) {
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setDescription(await Translate(`Lyrics thread already exists! <${metadataThread}>`));
            return inter.editReply({ embeds: [embed], ephemeral: true });
        }

        // ... rest of your synced lyrics implementation ...

        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setDescription(await Translate(`Synced lyrics updated in <${thread}>! <✅>`));
            
        return inter.editReply({ embeds: [successEmbed], ephemeral: true });

    } catch (error) {
        console.error(error);
        const errorEmbed = new EmbedBuilder()
            .setColor('#ff0000')
            .setDescription(await Translate('<❌> | Failed to process synced lyrics'));
        return inter.editReply({ embeds: [errorEmbed], ephemeral: true });
    }
}