const { Translate } = require('../process_tools');
const { QueueRepeatMode, useQueue, useMainPlayer } = require('discord-player');

module.exports = async ({ inter, client }) => {
    const player = useMainPlayer();
    const queue = useQueue(inter.guild);
    const channel = inter.member.voice.channel;

    if (!channel) {
        return inter.editReply({
            content: await Translate(`You need to be in a voice channel! <❌>`),
            ephemeral: true,
        });
    }

    try {
        // If queue doesn't exist or is empty, start autoplay
        if (!queue || !queue.isPlaying()) {
            client.commands.get('autoplay').execute({ inter, client });
            return;
        }

        // Toggle autoplay
        const currentMode = queue.repeatMode;
        const newMode = currentMode === QueueRepeatMode.AUTOPLAY
            ? QueueRepeatMode.OFF
            : QueueRepeatMode.AUTOPLAY;

        queue.setRepeatMode(newMode);

        inter.editReply({
            content: await Translate(newMode === QueueRepeatMode.AUTOPLAY
                ? `Autoplay enabled! Adding similar songs <🔁>`
                : `Autoplay disabled <❌>`),
            ephemeral: false,
        });

    } catch (error) {
        console.error('Autoplay Button Error:', error);
        inter.editReply({
            content: await Translate(`Failed to toggle autoplay! <❌>`),
            ephemeral: true,
        });
    }
};
