const { AttachmentBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');
const fs = require('fs');
const { Translate } = require('../../process_tools');

registerFont(path.join(__dirname, '../../fonts/Toxia-OwOA.ttf'), { family: 'CustomFont' });

function getServerSettings(guildId) {
    const settingsPath = path.join(__dirname, '../../serverSettings.json');
    let settings = {};

    if (fs.existsSync(settingsPath)) {
        try {
            settings = JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
        } catch (error) {
        }
    }

    settings[guildId] = settings[guildId] || { welcomeChannelId: "", leaveChannelId: "", autoRoleId: "" };
    return settings[guildId];
}

async function safeLoadImage(source) {
    try {
        return await loadImage(source);
    } catch (error) {
        throw error;
    }
}

async function safeLoadAvatar(user) {
    try {
        return await loadImage(user.displayAvatarURL({ 
            extension: 'png', 
            forceStatic: true,
            size: 256 
        }));
    } catch (error) {
        return await loadImage(`https://cdn.discordapp.com/embed/avatars/${user.discriminator % 5}.png`);
    }
}

module.exports = async (client, member) => {
    try {
        const guild = member.guild;
        const settings = getServerSettings(guild.id);

        if (settings.autoRoleId) {
            const role = guild.roles.cache.get(settings.autoRoleId);
            if (role) {
                if (guild.members.me.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
                    if (role.position < guild.members.me.roles.highest.position) {
                        await member.roles.add(role).catch(() => {});
                    }
                }
            }
        }

        const welcomeChannel = guild.channels.cache.get(settings.welcomeChannelId);
        if (!welcomeChannel) {
            return;
        }

        const missingPermissions = welcomeChannel.permissionsFor(client.user).missing([
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages
        ]);
        if (missingPermissions.length) {
            return;
        }

        const background = await safeLoadImage(path.join(__dirname, '../../assets/welcome-bg.png'));

        const avatar = await safeLoadAvatar(member.user);

        const canvas = createCanvas(700, 250);
        const ctx = canvas.getContext('2d');

        ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

        ctx.save();

        const avatarX = 100;
        const avatarY = canvas.height / 2;
        const avatarRadius = 75;

        ctx.beginPath();
        ctx.arc(avatarX, avatarY, avatarRadius + 5, 0, Math.PI * 2, true);
        ctx.fillStyle = 'black';
        ctx.fill();

        ctx.beginPath();
        ctx.arc(avatarX, avatarY, avatarRadius, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar, avatarX - avatarRadius, avatarY - avatarRadius, avatarRadius * 2, avatarRadius * 2);

        ctx.restore();

        ctx.font = '40px CustomFont, Arial';
        ctx.textAlign = 'center';

        async function drawTextWithOutline(text, x, y) {
            ctx.fillStyle = 'black';
            ctx.lineWidth = 6;
            ctx.strokeText(await Translate(text), x, y);
            ctx.fillStyle = 'white';
            ctx.fillText(await Translate(text), x, y);
        }

        await drawTextWithOutline(`Welcome, ${member.displayName}!`, canvas.width / 2, canvas.height - 40);

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle(await Translate('🎉 Welcome to the Server!'))
            .setDescription(await Translate(`Hey <@${member.id}>, welcome to **${guild.name}**! 🎊`))
            .setImage('attachment://welcome.png')
            .setTimestamp();

        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'welcome.png' });
        await welcomeChannel.send({ content: `<@${member.id}>`, embeds: [embed], files: [attachment] });

    } catch (error) {
    }
};

module.exports.leave = async (client, member) => {
    try {
        const guild = member.guild;
        const settings = getServerSettings(guild.id);

        const leaveChannel = guild.channels.cache.get(settings.leaveChannelId);
        if (!leaveChannel) {
            return;
        }

        const missingPermissions = leaveChannel.permissionsFor(client.user).missing([
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages
        ]);
        if (missingPermissions.length) {
            return;
        }

        const goodbyeMessages = [
            `Oh no! ${member.displayName} just rage quit the server. Who's next? 🤣`,
            `Goodbye ${member.displayName}! We will now talk behind your back. (Just kidding... or not? 👀)`,
            `${member.displayName} has left the building... and the chat. 🚪💨`,
            `F in the chat for ${member.displayName}. Their time here was legendary. 🎮`,
            `Wait! ${member.displayName}, come back! We were just about to start the fun! 🎉`,
            `Adios, ${member.displayName}! Hope your next server appreciates your memes more than we did. 😂`,
            `Another soldier down... ${member.displayName} has fallen. We shall remember you. 🫡`,
            `Breaking News: ${member.displayName} has officially vanished into the digital void. 🚀`,
            `Gone but not forgotten... unless we delete the chat history. 👀`,
            `${member.displayName} left us. Now we cry in 144p. 😭`
        ];

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle(await Translate('😢 Goodbye!'))
            .setDescription(await Translate(goodbyeMessages[Math.floor(Math.random() * goodbyeMessages.length)]))
            .setTimestamp();

        await leaveChannel.send({ embeds: [embed] });

    } catch (error) {
    }
};