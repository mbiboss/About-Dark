const { Translate } = require('../../process_tools');

module.exports = async (client) => {
    console.log(await Translate(`• 🎸 Logged in as <${client.user.username}>!`));

    const commandCount = client.commands ? client.commands.size : 0;
    console.log(await Translate(`• ✅ Synced ${commandCount} commands!`));

    console.log(await Translate("• 🔥 Let's Rock!"));

    client.user.setActivity(client.config.app.playing);
};
