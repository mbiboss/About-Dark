const { EmbedBuilder, InteractionType, MessageFlags, PermissionsBitField } = require('discord.js');
const { useQueue } = require('discord-player');
const { Translate } = require('../../process_tools');

module.exports = async (client, inter) => {
    // Defer reply once for all commands
    if (!inter.deferred && !inter.replied) {
        await inter.deferReply({ ephemeral: true });
    }

    if (inter.type === InteractionType.ApplicationCommand) {  
        const DJ = client.config.opt.DJ;  
        const command = client.commands.get(inter.commandName);  
        const isJoinCommand = inter.commandName === 'join';  
        const isLeaveCommand = inter.commandName === 'leave';  

        const errorEmbed = new EmbedBuilder().setColor('#ff0000');  

        if (!command) {  
            errorEmbed.setDescription(await Translate('<❌> | Error! Please contact the Developers!'));  
            return inter.editReply({ embeds: [errorEmbed], ephemeral: true });  
        }  

        // DJ Role Check  
        const djRole = inter.guild.roles.cache.find(x => x.name === '◁━━━━◈DJ◈━━━━▷');  
        const isDJ = djRole && inter.member.roles.cache.has(djRole.id);

        // Check if user has required permissions or DJ role  
        if (command.permissions && !inter.member.permissions.has(command.permissions) && !isDJ) {  
            errorEmbed.setDescription(await Translate('<❌> | You might not have enough permissions to use this command.'));  
            return inter.editReply({ embeds: [errorEmbed], ephemeral: true });  
        }  

        // Additional DJ commands check  
        if (DJ.enabled && DJ.commands.includes(command.name) && !isDJ) {  
            errorEmbed.setDescription(await Translate(`<❌> | This command is reserved for members with the \`◁━━━━◈DJ◈━━━━▷\` role.`));  
            return inter.editReply({ embeds: [errorEmbed], ephemeral: true });  
        }  

        // Voice channel checks  
        if (command.voiceChannel) {  
            if (isJoinCommand) {  
                if (!inter.member.voice.channel) {  
                    errorEmbed.setDescription(await Translate('<❌> | You need to be in a voice channel to summon me!'));  
                    return inter.editReply({ embeds: [errorEmbed], ephemeral: true });  
                }  
                return command.execute({ inter, client });  
            }  

            if (isLeaveCommand) {  
                return command.execute({ inter, client });  
            }  

            if (!inter.member.voice.channel) {  
                errorEmbed.setDescription(await Translate('<❌> | You are not in a Voice Channel.'));  
                return inter.editReply({ embeds: [errorEmbed], ephemeral: true });  
            }  

            if (inter.guild.members.me.voice.channel && inter.member.voice.channel.id !== inter.guild.members.me.voice.channel.id) {  
                errorEmbed.setDescription(await Translate('<❌> | You are not in the same Voice Channel.'));  
                return inter.editReply({ embeds: [errorEmbed], ephemeral: true });  
            }  
        }  

        // Execute the command with error handling
        try {
            await command.execute({ inter, client });
        } catch (error) {
            console.error(`Error executing command ${command.name}:`, error);
            errorEmbed.setDescription(await Translate('<❌> | An error occurred while executing the command.'));
            return inter.editReply({ embeds: [errorEmbed], ephemeral: true });
        }

    } else if (inter.type === InteractionType.MessageComponent) {  
        const customId = inter.customId;  
        if (!customId) return;  

        const queue = useQueue(inter.guild.id);  
        const path = `../../buttons/${customId}.js`;  

        try {
            const button = require(path);
            if (typeof button === 'function') {
                await button({ client, inter, customId, queue });
            } else {
                await inter.editReply({ content: `❌ | Button handler for '${customId}' is not properly exported.`, ephemeral: true });
            }
        } catch (error) {
            console.error(`Error handling button '${customId}':`, error);
            await inter.editReply({ content: `❌ | An error occurred while handling the '${customId}' button.`, ephemeral: true });
        }
    }
};