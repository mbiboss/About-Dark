const { readdirSync } = require("fs");
const { Collection, PermissionsBitField } = require("discord.js");
const { useMainPlayer } = require("discord-player");
client.commands = new Collection();
const commandsArray = [];
const player = useMainPlayer();

const { Translate, GetTranslationModule } = require("./process_tools");

const discordEvents = readdirSync("./events/Discord/").filter((file) =>
  file.endsWith(".js")
);
const playerEvents = readdirSync("./events/Player/").filter((file) =>
  file.endsWith(".js")
);

GetTranslationModule().then(() => {
  console.log("| Translation Module Loaded |");

  // Load Discord events
  for (const file of discordEvents) {
    const DiscordEvent = require(`./events/Discord/${file}`);
    const eventName = file.split(".")[0];
    const txtEvent = `• ✳️ Loaded Discord Event: <${eventName}>`;
    parseLog(txtEvent);
    client.on(eventName, DiscordEvent.bind(null, client));
    delete require.cache[require.resolve(`./events/Discord/${file}`)];
  }

  // Load Player events
  for (const file of playerEvents) {
    const PlayerEvent = require(`./events/Player/${file}`);
    const eventName = file.split(".")[0];
    const txtEvent = `• ⭐ Loaded Player Event: <${eventName}>`;
    parseLog(txtEvent);
    player.events.on(eventName, PlayerEvent.bind(null));
    delete require.cache[require.resolve(`./events/Player/${file}`)];
  }

  // Load commands
  readdirSync("./commands/", { withFileTypes: true }).forEach((dir) => {
    if (dir.isDirectory()) {
      const commands = readdirSync(`./commands/${dir.name}/`).filter((file) =>
        file.endsWith(".js")
      );

      for (const file of commands) {
        const command = require(`./commands/${dir.name}/${file}`);
        let commandData;

        // Legacy command format (e.g., back.js)
        if (command.name && command.description) {
          commandData = {
            name: command.name,
            description: command.description,
            options: command.options || [],
            default_member_permissions: command.voiceChannel
              ? PermissionsBitField.Flags.Connect
              : null
          };
          client.commands.set(command.name.toLowerCase(), command);
        }
        // Slash command format (e.g., setwelcome.js)
        else if (command.data && command.execute) {
          commandData = command.data.toJSON();
          client.commands.set(command.data.name, command);
        } else {
          console.log(`• ❌ Failed to load command: ${file}`);
          continue;
        }

        commandsArray.push(commandData);
        console.log(`• ✅ Loaded command: ${commandData.name}`);
      }
    }
  });

  // Register slash commands
  client.on("ready", async (client) => {
    if (client.config.app.global) {
      await client.application.commands.set(commandsArray);
    } else {
      const guild = client.guilds.cache.get(client.config.app.guild);
      if (guild) await guild.commands.set(commandsArray);
    }
  });

  // Load welcome/leave events
  const welcomeLeave = require("./events/Discord/welcomeLeave");
  client.on("guildMemberAdd", (member) => welcomeLeave(client, member));
  client.on("guildMemberRemove", (member) => welcomeLeave.leave(client, member));

  async function parseLog(txtEvent) {
    console.log(await Translate(txtEvent, null));
  }
});