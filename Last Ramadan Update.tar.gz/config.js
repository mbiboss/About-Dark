module.exports = {
  "app": {
    "token": "MTMzNDA2MzIwMDI1MzEyMDUyMg.GBDv4A.jXqE0ZlfTCxxdnHMPC3RN3C8TdkpP6gEv_6RxY",
    "playing": "💮শূন্যের শূন্যতায় শূন্যস্থান শূন্য 🥀",
    "global": true,
    "guild": "xxx",
    "extraMessages": false,
    "loopMessage": false,
    "lang": "bn",
    "enableEmojis": false,
    "welcome": {
      "enabled": true,
      "bgImage": "./assets/welcome-bg.png",
      "font": "./fonts/Toxia-OwOA.ttf"
    }
  },
  "emojis": {
    "back": "⏪",
    "skip": "⏩",
    "ResumePause": "⏯️",
    "savetrack": "💾",
    "volumeUp": "🔊",
    "volumeDown": "🔉",
    "loop": "🔁"
  },
  "opt": {
    "DJ": {
      "enabled": false,
      "roleName": "",
      "commands": []
    },
    "Translate_Timeout": 10000,
    "maxVol": 100,
    "spotifyBridge": true,
    "volume": 75,
    "leaveOnEmpty": true,
    "leaveOnEmptyCooldown": 120000,
    "leaveOnEnd": true,
    "leaveOnEndCooldown": 120000,
    "discordPlayer": {
      "ytdlOptions": {
        "quality": "highestaudio",
        "highWaterMark": 33554432
      }
    }
  }
};