module.exports = {
    img1: 'https://i.postimg.cc/kGQkF9LH/felix-acidcat.gif', // felix-acidcat.gif
    img2: 'https://i.postimg.cc/0yjGwmHJ/banner.gif', // banner.gif
    img3: 'https://i.postimg.cc/MTvjDs38/footer.gif', // footer.gif
    img4: 'https://i.postimg.cc/kXXPhkF8/serverlogo.png', // serverlogo.png
    img5: 'https://i.postimg.cc/rF6jbHTC/mbiboss.jpg'//mbidark
    // Add more images as needed
};